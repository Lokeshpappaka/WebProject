# Images Folder

Please place your images in this folder with the following names:

1. **burger.jpg** - The main burger image with fries and sauces (for the first section)
2. **neon-signs.jpg** - Night scene with neon signs "THE STAGE ON BROADWAY" (top-left grid image)
3. **outdoor-cafe.jpg** - Outdoor cafe/restaurant scene with tables and awnings (bottom-left grid image)
4. **gourmet-food.jpg** - Gourmet food spread on dark wooden table (right-side grid image)

All images should be placed in this folder for the website to display correctly.

